Imports System
Imports System.Collections.Generic
Imports DevExpress.ExpressApp
Imports System.Reflection
Imports DevExpress.Persistent.BaseImpl

Partial Public NotInheritable Class [$projectsuffix$Module]
    Inherits ModuleBase
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
