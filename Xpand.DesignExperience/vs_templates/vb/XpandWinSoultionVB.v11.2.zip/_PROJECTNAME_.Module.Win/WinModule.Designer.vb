Imports Microsoft.VisualBasic
Imports System
Imports Xpand.ExpressApp.MemberLevelSecurity.Win

Partial Public Class $projectsuffix$WindowsFormsModule
    ''' <summary> 
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary> 
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (Not components Is Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Component Designer generated code"

    ''' <summary> 
    ''' Required method for Designer support - do not modify 
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        '
        'TemplateSolutionWindowsFormsModule
        '
        Me.RequiredModuleTypes.Add(GetType($safesolutionname$.[Module].$projectsuffix$Module))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.Win.SystemModule.SystemWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.FileAttachments.Win.FileAttachmentsWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.ConditionalAppearance.ConditionalAppearanceModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.HtmlPropertyEditor.Win.HtmlPropertyEditorWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.PivotChart.Win.PivotChartWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.Reports.Win.ReportsWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.Scheduler.Win.SchedulerWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.TreeListEditors.Win.TreeListEditorsWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(DevExpress.ExpressApp.Validation.Win.ValidationWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.SystemModule.XpandSystemModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.ModelDifference.Win.ModelDifferenceWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.TreeListEditors.Win.XpandTreeListEditorsWinModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.Win.SystemModule.XpandSystemWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.WizardUI.Win.WizardUIWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.WorldCreator.Win.WorldCreatorWinModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.IO.Win.IOWinModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.ExceptionHandling.Win.ExceptionHandlingWinModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.FilterDataStore.Win.FilterDataStoreWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.AdditionalViewControlsProvider.Win.AdditionalViewControlsProviderWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.PivotChart.Win.XpandPivotChartWinModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.MasterDetail.Win.MasterDetailWindowsModule))
        Me.RequiredModuleTypes.Add(GetType(MemberLevelSecurityModuleWin))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.ImportWizard.Win.ImportWizardWindowsFormsModule))
        Me.RequiredModuleTypes.Add(GetType(Xpand.ExpressApp.Validation.Win.XpandValidationWinModule))


    End Sub

#End Region
End Class
